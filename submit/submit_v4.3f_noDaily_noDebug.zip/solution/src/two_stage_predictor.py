import pickle
import copy
from collections import defaultdict
from timeit import default_timer as timer

import numpy as np
import pandas as pd
import json
from scipy import sparse as sp
from catboost import CatBoost, Pool
import lightgbm as lgb
from scipy.stats import rankdata

from src.utils import (
    ProductEncoder,
    make_coo_row
)

from src.utils_mini import ProductEncoderMini

from src.featurizer import (
    init_product_info_map, 
    ClientProfile, 
    FeatureExtractor,
    CandidatSelector
)

from src.featurizer.nn import WrapperNnModel, AwesomeModel, AwesomeModel2, AwesomeFm
from src.featurizer.daily import DailyScorer
from src.featurizer.feature_extractor import ImplicitWrapperMini, SVDWrapperMini


class TwoStagePredictor:

    def __init__(self, global_top_path, assets_root):
        print("Start loading Predictor..")
        start = timer()

        self.product_encoder = ProductEncoder(assets_root + "/products_orig.parquet")
        self.product_info_map = init_product_info_map(assets_root + '/product_ext_2.parquet')
        global_top_products = json.load(open(global_top_path))
        self.actual_products = json.load(open(assets_root + '/actual_items.json'))
        self.actual_product_encoder = ProductEncoderMini(self.actual_products)

        tagged_models = [
            (pickle.load(open(assets_root + '/cosine1/model.pkl', "rb")), "cosine1"),
        ]

        mini_models = [
            (ImplicitWrapperMini(self.actual_product_encoder, assets_root + "/implicit_mini/tf1/"), "Mtf1"),
            (ImplicitWrapperMini(self.actual_product_encoder, assets_root + "/implicit_mini/tf10/"), "Mtf10"),
        ]

        self.feature_extractor = FeatureExtractor(
            self.product_info_map,
            self.product_encoder,
            global_top=global_top_products[:2000],
            tagged_models=tagged_models,
            mini_models=mini_models,
            lvl4_model=pickle.load(open(assets_root + '/L4_cosine10/model.pkl', "rb")),
            nn2_2=WrapperNnModel(
                constructor=AwesomeModel2,
                product_encoder_mini=self.actual_product_encoder,
                model_path=assets_root + '/nn2.2/d512/model_cpu.pth'
            ),
            daily_scorer=DailyScorer(scorer_path=assets_root + '/daily_tops_v2.pickle')
        )

        self.candidate_selector = CandidatSelector(
            model=CatBoost().load_model(assets_root + '/model_v4.3_candidates.cbm'),
            global_top=global_top_products[:50],
            product_info_map=self.product_info_map
        )

        self.cb_reranker = CatBoost().load_model(assets_root + '/model_v4.3f_skip_fmDaily.cbm')
        self.lgb_reranker = lgb.Booster(model_file=assets_root + '/model_4.3f_noDaily.lgb')

        end = timer()
        print("->Loading took {}s".format(end - start))

 
    def rows_to_df(self, rows):
        features = pd.DataFrame(rows)
        return features[sorted(features.columns)].fillna(-1)


    def df_to_pool(self, df):
        num_names = [x for x in df.columns if not x.startswith('_')]
        return Pool(
            data=df[num_names],
            cat_features=["product_truncated_id", "product_level1_id", 
                      "product_level2_id", "product_level3_id", 
                      "product_level4_id", "product_segment_id", "product_vendor_id", "product_brand_id"],
        )


    def predict(self, js,k=30):
        profile = ClientProfile(
            product_info_map=self.product_info_map, 
            product_encoder=self.product_encoder,
            actual_product_encoder=self.actual_product_encoder,
            client_js=js
        )

        precalc = self.feature_extractor.build_precalc(profile)
        candidates = self.candidate_selector.get_candidates(profile, precalc)

        rows = self.feature_extractor.build_features(profile, precalc, candidates, js['query_time'])
        features_df = self.rows_to_df(rows)

        # cb part
        cb_pool = self.df_to_pool(features_df)
        cb_scores = self.cb_reranker.predict(cb_pool)

        # lgb part
        skip_features=[
            "product_truncated_id", "product_level1_id",      
            "product_level2_id", "product_level3_id",   
            "product_level4_id", "product_segment_id", 
            "product_vendor_id", "product_brand_id",
            'model_fm22_rank', 'model_fm22_score',
            "model_daily_score" # boom!
        ]
        lgb_feature_names = [x for x in features_df.columns if not x.startswith('_') and x not in skip_features]
        lgb_scores = self.lgb_reranker.predict(features_df[lgb_feature_names])

        scores = rankdata(cb_scores) + rankdata(lgb_scores)
        return list(np.array(candidates)[np.argsort(-scores)][:30])

        

        
