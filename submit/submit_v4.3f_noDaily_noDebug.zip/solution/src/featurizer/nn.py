import itertools
import json
import os
from collections import defaultdict
from typing import List, Set

import numpy as np
import torch
from scipy import sparse as sp
from torch import nn
from tqdm.notebook import tqdm

from src.utils_mini import (
    ProductEncoderMini,
    make_coo_row_mini
)

from src.utils import (
    coo_to_pytorch_sparse,
    TrainingSample,
    normalized_average_precision,
)

from src.featurizer.client_profile import JsonType

class AwesomeModel(nn.Module):
    def __init__(self, num_products):
        super(AwesomeModel, self).__init__()
        self._model = nn.Sequential(
            nn.Linear(num_products, 512),
            nn.Linear(512, num_products) 
        )

    def forward(self, x):
        return self._model(x)


class AwesomeModel2(nn.Module):
    def __init__(self, num_products):
        super(AwesomeModel2, self).__init__()
        self._fc1 = nn.Linear(num_products, 512)
        self._fc2 = nn.Linear(512, num_products)
        

    def forward(self, x):
        x = self._fc1(x)
        return self._fc2(x)


class AwesomeFm(nn.Module):
    def __init__(self, num_products):
        super(AwesomeFm, self).__init__()
        self._fc1 = nn.Linear(num_products, 256)
        self._fc2 = nn.Linear(256, num_products)
        

    def forward(self, x):
        x = self._fc1(x)
        x = x ** 2
        return self._fc2(x)


class WrapperNnModel:
    def __init__(self, constructor, product_encoder_mini: ProductEncoderMini, model_path: str):
        self._pe = product_encoder_mini
        self._model = constructor(self._pe.num_products)
        self._model.load_state_dict(torch.load(model_path))

    def predict(self, transaction_history: JsonType):
        row = make_coo_row_mini(transaction_history, self._pe)
        X = coo_to_pytorch_sparse(row)
        outs = self._model.forward(X)
        return {pid:score for (pid, score) in zip(self._pe._all_pids, outs.data.numpy()[0])}   
        

